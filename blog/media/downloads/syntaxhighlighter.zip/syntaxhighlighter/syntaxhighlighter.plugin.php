<?php

Class SyntaxHighlighter extends Plugin {

	var $languages = array ();

	public function info () {
		return array(
				'name'=>'SyntaxHighlighter',
				'version'=>'0.1',
				'url'=>'http://gopherwood.info',
				'author'=>'wayne',
				'authorurl'=>'http://gopherwood.info/',
				'license'=>'Apache License 2.0',
				'description'=>'Highlight source code in post'
			    );
	}

	public function theme_header ($theme) {
		Stack::add ('template_stylesheet', array ($this->get_url() . '/dp.SyntaxHighlighter/Styles/SyntaxHighlighter.css', 'screen'), 'style');
	}

	public function theme_footer ($theme) {
		$brushes = $this->get_language_array ();

		if (count ($this->languages)) {
			$scripts = <<<CORE

<script type="text/javascript" src="URL/dp.SyntaxHighlighter/Scripts/shCore.js"></script>
CORE;
			foreach ($this->languages as $lang => $dummy) {
				$script = <<<LANGUAGES

<script type="text/javascript" src="URL/dp.SyntaxHighlighter/Scripts/BRUSH"></script>
LANGUAGES;
				$script = str_replace ("BRUSH", $brushes[$lang], $script);
				$scripts .= $script;
			}

			$script = <<<SWF

<script type="text/javascript">
dp.SyntaxHighlighter.ClipboardSwf = "URL/dp.SyntaxHighlighter/Scripts/clipboard.swf";
dp.SyntaxHighlighter.BloggerMode ();
dp.SyntaxHighlighter.HighlightAll('code');
</script>
SWF;
			$scripts .= $script;

			$scripts = str_replace ("URL", $this->get_url (), $scripts);
			
			echo $scripts;
		}
	}

	public function filter_post_content_out ($content) {	
		$regex = '/\[(sourcecode)( lang=[\'"])';
		
		$regex .= $this->get_language_regex ();
		
		$regex .= '[\'"]\](.*?)\[\/sourcecode\]/si';

		preg_match_all ($regex, $content, $matches, PREG_SET_ORDER);

		foreach ($matches as $match) {
			$source = $match[4]; 
			$content = str_replace ($match[0], "<textarea name='code' class='$match[3]'>$source</textarea>", $content);
			$this->load_language ($match[3]);
		}

		return $content;
	}

	private function get_language_array () {
		return array (
				'cpp'        => 'shBrushCpp.js',
				'c'          => 'shBrushCpp.js',
				'c++'        => 'shBrushCpp.js',
				'c#'         => 'shBrushCSharp.js',
				'c-sharp'    => 'shBrushCSharp.js',
				'csharp'     => 'shBrushCSharp.js',
				'css'        => 'shBrushCss.js',
				'delphi'     => 'shBrushDelphi.js',
				'pascal'     => 'shBrushDelphi.js',
				'java'       => 'shBrushJava.js',
				'js'         => 'shBrushJScript.js',
				'jscript'    => 'shBrushJScript.js',
				'javascript' => 'shBrushJScript.js',
				'php'        => 'shBrushPhp.js',
				'py'         => 'shBrushPython.js',
				'python'     => 'shBrushPython.js',
				'rb'         => 'shBrushRuby.js',
				'ruby'       => 'shBrushRuby.js',
				'rails'      => 'shBrushRuby.js',
				'ror'        => 'shBrushRuby.js',
				'sql'        => 'shBrushSql.js',
				'vb'         => 'shBrushVb.js',
				'vb.net'     => 'shBrushVb.js',
				'xml'        => 'shBrushXml.js',
				'html'       => 'shBrushXml.js',
				'xhtml'      => 'shBrushXml.js',
				'xslt'       => 'shBrushXml.js'
					);
	}

	private function get_language_regex () {
		$keys = array_keys ($this->get_language_array ());

		$regex = '(' . $keys[0];
		for ($i = 1; $i < count ($keys); $i++) {
			$regex .= "|$keys[$i]";
		}
		$regex .= ')';

		return $regex;
	}

	private function load_language ($lang) {
		$this->languages[$lang] = true;
	}
}
?>
