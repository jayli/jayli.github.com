<!-- comments -->
<?php // Do not delete these lines
if ( ! defined('HABARI_PATH' ) ) { die( _t('Please do not load this page directly. Thanks!') ); }
?>
<?php
function outputReplyLink ($comment) {
  echo "<div class='reply-link'><a href='#' onclick='movecfm (event, " . $comment->id . ", 1, \"" . $comment->name  . "\"); return false;'>" . _t('Reply') . "</a></div>";
}

function outputComment ($post, $comment, $level, $max_depth) {
	if ($comment->url_out == '') {
		$comment_url = $comment->name_out;
	} else {
		$comment_url = '<a href="' . $comment->url_out . '" rel="external">' . $comment->name_out . '</a>';
	}

	$class = 'class="comment';
	if ( $comment->status == Comment::STATUS_UNAPPROVED ) {
		$class .= '-unapproved';
	}

	// check to see if the comment is by a registered user
	if ($u = User::get($comment->email)) {
		$class .= ' byuser comment-author-' . Utils::slugify ($u->displayname);
	}

	if ($comment->email == $post->author->email) {
		$class .= ' bypostauthor';
	}

	if ($level > 1) {
		$class .= ' comment-child';
	}

	if ($level % 2) {
		$class .= ' odd';
	} else {
		$class .= ' even';
	}

	$class.= '"';
?>
      <<?php echo $level == 1 ? 'li' : 'div'; ?> id="comment-<?php echo $comment->id; ?>" <?php echo $class; ?> >
       <a href="#comment-<?php echo $comment->id; ?>" class="counter" title="<?php _e('Permanent Link to this Comment'); ?>"><?php echo $comment->id; ?></a>
       <span class="commentauthor"><?php echo $comment_url; ?></span>
       <small class="comment-meta"><a href="#comment-<?php echo $comment->id; ?>" title="<?php _e('Time of this Comment'); ?>"><?php $comment->date->out(); ?></a><?php if ( $comment->status == Comment::STATUS_UNAPPROVED ) : ?> <em><?php _e('In moderation'); ?></em><?php endif; ?></small>

       <div class="comment-content">
        <?php echo $comment->content_out; ?>
       </div>

       <?php
	if ($level < $max_depth) {
		outputReplyLink ($comment);
	}

	if (isset ($comment->children)) {
		foreach ($comment->children as $c) {
			outputComment ($post, $c, $level + 1, $max_depth);
		}
	}
	?>
      <?php echo $level == 1 ? '</li>' : '</div>'; ?>
<?php
}
?>
    <hr>

    <div class="comments">
     <h4><span id="comments"><?php echo $post->comments->moderated->count; ?> <?php _e('Responses to'); ?> <?php echo $post->title; ?></span></h4>
     <div class="metalinks">
      <span class="commentsrsslink"><a href="<?php echo $post->comment_feed_link; ?>"><?php _e('Feed for this Entry'); ?></a></span>
     </div>

     <ol id="commentlist">
<?php
if ( $post->comments->moderated->count ) {
	foreach ( $post->threadedComments as $comment ) {
		outputComment ($post, $comment, 1, $theme->commentThreadMaxDepth);
	}
} else { ?>
      <li><?php _e('There are currently no comments.'); ?></li>
<?php } ?>
     </ol>

<?php if ( ! $post->info->comments_disabled ) { include_once( 'commentform.php' ); } ?>

     <hr>

    </div>
<!-- /comments -->
