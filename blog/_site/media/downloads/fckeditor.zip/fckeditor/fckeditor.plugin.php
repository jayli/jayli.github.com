<?php
class FckEditor extends Plugin {

  /* Required Plugin Informations */
  public function info() {
    return array(
      'name' => 'FckEditor',
      'version' => '0.1',
      'url' => 'http://gopherwood.info/',
      'author' => 'wayne',
      'authorurl' => 'http://gopherwood.info/',
      'license' => 'Apache License 2.0',
      'description' => 'Fckeditor Plugin for Habari'
    );
  }

  /**
   * Add the JavaScript required for the NicEdit editor to the publish page
   */
  public function action_admin_header($theme)
  {
    if ( $theme->admin_page == 'publish' ) {
      Stack::add( 'admin_header_javascript', $this->get_url() . '/fckeditor/fckeditor.js', 'fckeditor' );
    }
  }

  /**
   * Instantiate the NicEdit editor and enable media silos
   */
  public function action_admin_footer($theme) {
    if ( $theme->admin_page == 'publish' ) {
      $js = <<<FCKEDITOR
      <script type="text/javascript">
      window.onload = function() {
        var oFCKeditor = new FCKeditor( 'content' ) ;
        oFCKeditor.BasePath = "URL/fckeditor/";
        oFCKeditor.ReplaceTextarea() ;
      }
      </script>
FCKEDITOR;
      $js = str_replace ("URL", $this->get_url(), $js);
      echo $js;
    }
  }
}
?>
