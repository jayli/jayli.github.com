<?php
/*
Plugin Name: Feedsky Feed 插件
Plugin URI: http://rpc.feedsky.com/plugins
Description: 这个插件可以协助你在Blog（仅限于Wordpress系统）中使用Feedsky Feed相关功能。目前该插件功能包括：1、Ping Feedsky；2、Feed 转向。
Author: 哈啰波波
Version: 1.2 test
Author URI: http://my.donews.com/blogbug
*/ 

add_action('admin_menu', 'feedsky_feed_plugins_conf_page');
define("FSP_FEEDNAME", 'feedsky_ping_feed_name');
define("FSP_FEEDURL", 'feedsky_feed_url');
define("FSP_PINGSERV", 'feedsky_feed_ping_serv');
define("FSP_REDRSERV", 'feedsky_feed_redr_serv');

function feedsky_feed_plugins_conf_page() {
	global $wpdb;
	
	if ( function_exists('add_submenu_page') )
		add_submenu_page('plugins.php', __('Feedsky Feed 插件'), __('Feedsky Feed 插件'), 1, __FILE__, 'feedsky_feed_conf');
}

function feedsky_feed_conf() {
	$submit_text = trim($_POST['submit']);
	if ( isset($submit_text) ) {
		check_admin_referer();
		// $key = preg_replace('/[^a-h0-9]/i', '', $_POST['key']);
		if( strpos($submit_text, "Feed Config") )
		{
			$key = trim($_POST['key']);
			$feedurl = trim($_POST['feedurl']);
			if ( feedsky_ping_verify_key( $key ) ) {
				update_option(FSP_FEEDNAME, $key);
			} else {
				$invalid_key = true;
			}
			update_option(FSP_FEEDURL, $feedurl);
		} else if( strpos($submit_text, "Ping On") ) {
			update_option(FSP_PINGSERV, "on");
		} else if( strpos($submit_text, "Ping Off") ) {
			update_option(FSP_PINGSERV, "off");
		} else if( strpos($submit_text, "Redr On") ) {
			update_option(FSP_REDRSERV, "on");
		} else if( strpos($submit_text, "Redr Off") ) {
			update_option(FSP_REDRSERV, "off");
		}
	}
	if ( !feedsky_ping_verify_key( get_option(FSP_FEEDNAME) ) )
		$invalid_key = true;
?>

<div class="wrap">
<h2><?php _e('Feedsky Feed 插件介绍'); ?></h2>
<p><a href="http://www.feedsky.com" target="_blank">Feedsky</a>是一家Feed管理服务商，提供给Blogger（博客）、网站（Website）和商业出版者等内容出版者在线的服务平台，帮助他们加强Feed的优化和传播管理。
Feedsky会处理用户的Feed格式，使用户的Feed能够自动适应各种RSS格式以及各种阅读器，同时还会帮助用户建立一个面向读者的订阅引导页面，并且统计每天、每周和每月的读者数量和使用的阅读器种类及文章点击数。</p>
<p>该插件是Feedsky为Wordpress用户专门提供的功能性辅助插件，用以快速直接的使用Feedsky的相关服务。插件需要你提供你在Feedsky上的Feed名称，请先进行 <a href="#fpp_0">Feedsky Feed 绑定</a>。
目前该插件包括两个功能：
	<ul>
	<li><a href="#fpp_1">Ping 服务 （默认启用）</a></li>
	<li><a href="#fpp_2">Feed 转向 （默认启用）</a></li>
	</ul>
</p>

<form action="" method="post" id="feedsky-ping-conf">

<fieldset style="border:1px solid #ddd;padding:24px;">
<legend style="font-size:16px;"><a name="fpp_0">Feedsky Feed 绑定</a></legend>
<p style="clear:both;">第一步：<a href="http://www.feedsky.com/add_feed.php?source_url=<?php echo get_settings('home') . '/'; ?>" target="_blank" title="单击创建">在 Feedsky 创建 <strong>[<?php bloginfo('name') ?>]</strong> 的 Feed</a>，如果已经创建，请继续第二步；<br></p>
<p style="clear:both;"><label for="key">第二步：<?php _e('请输入该Blog在Feedsky上的Feed名称'); ?>，比如： http://feed.feedsky.com/<span style="color:#00F;"><strong><u>blogbug</u></strong></span>，则只需要输入 <span style="color:#F00;"><strong><u>blogbug</u></strong></span></label>
	<div style="float:left;margin-left:25px;"><input id="key" name="key" type="text" size="18" maxlength="32" value="<?php echo get_option(FSP_FEEDNAME); ?>" style="font-family: 'Courier New', Courier, mono; font-size: 1.5em;" /></div>
	<div style="float:left;margin-left:25px;"><input id="feedurl" name="feedurl" type="text" size="60" value="<?php echo get_option(FSP_FEEDURL); ?>" style="font-family: 'Courier New', Courier, mono; font-size: 1.5em;" /></div>
<?php if ( $invalid_key ) { ?>
	<div style="float:left;margin:3px;padding: 4px; background-color: #f33; color: #fff; font-weight: bold;"><?php _e('请输入该Blog在Feedsky上的Feed名称。'); ?></div>
	<div style="float:left;margin:3px;padding: 4px; background-color: #f33; color: #fff; font-weight: bold;"><?php _e('请输入该Blog在Feedsky上的Feed名称。'); ?></div>
<?php } ?>
</p>
<p class="submit" style="clear:both;text-align:center;"align="center"><input type="submit" name="submit" value="<?php _e('更新 Feedsky Feed 配置 [Feed Config] &raquo;'); ?>" /></p>

</fieldset>
	
<?php if ( !$invalid_key ) { ?>
	
<fieldset style="border:1px solid #ddd;padding:24px;">
<legend style="font-size:16px;"><a name="fpp_1">Feedsky Ping 功能</a></legend>
<p><a href="http://rpc.feedsky.com/ping">Ping Feedsky</a> 是Feedsky针对Feed内容更新提供的一个强大功能。
启用这个插件后，当您更新了Blog，便会自动向Feedsky发送通知，Feedsky的爬虫会立即对内容进行抓取，以保证您的Feed得到最快速度的更新。</p>

<?php if ( get_option(FSP_PINGSERV) == 'off' ) { ?>
当前状态：<span style="padding: 4px; background-color: #f33; color: #fff; font-weight: bold;"><?php _e('停用'); ?></span>
<p class="submit" style="clear:both;text-align:center;"align="center"><input type="submit" name="submit" value="<?php _e('启用 Feedsky Ping 服务 [Ping On]  &raquo;'); ?>" /></p>
<?php } else { ?>
当前状态：<span style="padding: 4px; background-color: #40FF40; color: #00F; font-weight: bold;"><?php _e('启用'); ?></span>
<p class="submit" style="clear:both;text-align:center;"align="center"><input type="submit" name="submit" value="<?php _e('停用 Feedsky Ping 服务 [Ping Off] &raquo;'); ?>" /></p>
<?php } ?>

</fieldset>
	
<fieldset style="border:1px solid #ddd;padding:24px;">
<legend style="font-size:16px;"><a name="fpp_2">Feedsky Feed 转向功能</a></legend>
<p>Feedsky Feed转向功能，可以将对您Blog中所有RSS Feed的请求和流量，完全转至您在Feedsky生成的Feed地址，您无需通知已有的大量订阅用户进行任何更改，便可以享受到更专业的Feed统计和管理服务了。</p>

<?php if ( get_option(FSP_REDRSERV) == 'off' ) { ?>
当前状态：<span style="padding: 4px; background-color: #f33; color: #fff; font-weight: bold;"><?php _e('停用'); ?></span>
<p class="submit" style="clear:both;text-align:center;"align="center"><input type="submit" name="submit" value="<?php _e('启用 Feedsky 转向服务 [Redr On]  &raquo;'); ?>" /></p>
<?php } else { ?>
当前状态：<span style="padding: 4px; background-color: #40FF40; color: #00F; font-weight: bold;"><?php _e('启用'); ?></span>
<p class="submit" style="clear:both;text-align:center;"align="center"><input type="submit" name="submit" value="<?php _e('停用 Feedsky 转向服务 [Redr Off]  &raquo;'); ?>" /></p>
<?php } ?>

</fieldset>
	
</form>
</div>
	
<?php } ?>

<?php
}

function feedsky_ping_verify_key( $key ) {
	if( strlen($key) > 3 ) {
		// return true;
		
		// $response = http_request("feed.feedsky.com", 80, "GET", "/{$key}", "");
		$response = http_request("rpc.feedsky.com", 80, "POST", "/ping/wp", "bsp=feedsky&burl={$key}");
		// print_r($response);
		if( $response && (strpos($response, "<value>1</value>") > 0) )
			return true;
	}
	return false;
}

if ( !get_option(FSP_FEEDNAME) && !isset($_POST['submit']) ) {
	function feedsky_ping_warning() {
	$path = plugin_basename(__FILE__);
		echo "
		<div id='feedsky-ping-warning' class='updated fade-ff0000'><p><strong>".__('Feedsky Feed 插件没有配置完整：')."</strong> ".sprintf(__('必须 <a href="%1$s">输入当前Blog在Feedsky上对应的Feed地址</a>。'), "plugins.php?page=$path")."</p></div>
		<style type='text/css'>
		#adminmenu { margin-bottom: 5em; }
		#feedsky-ping-warning { position: absolute; top: 7em; padding:12px 48px; }
		</style>
		";
	}
	add_action('admin_footer', 'feedsky_ping_warning');
	return;
}

function http_request($host, $port = 80, $mothod = "POST", $path, $query_string) {
	$path = "http://{$host}{$path}";
	$http_request  = "{$mothod} $path HTTP/1.0\r\n";
	$http_request .= "Host: $host\r\n";
	$http_request .= "Content-Type: application/x-www-form-urlencoded; charset=" . get_settings('blog_charset') . "\r\n";
	$http_request .= "User-Agent: Feedsky Ping plugin for wordpress.\r\n";
	$http_request .= 'Content-Length: '.strlen($query_string)."\r\n";
	$http_request .= "\r\n";
	$http_request .= $query_string;
	
	$response = '';
	if( false !== ( $fs = @fsockopen($host, $port, $errno, $errstr, 3) ) ) {
		fwrite($fs, $http_request);

		while ( !feof($fs) )
			$response .= fgets($fs, 1024); // One TCP-IP packet
		fclose($fs);
	}
	
	return $response;
}

function feedsky_ping_doing($id) {
	$burl = get_option(FSP_FEEDNAME);
	
	$host = "rpc.feedsky.com";
	$path = "/ping/wp";
	$query_string = "bsp=feedsky&burl=$burl";
	
	http_request($host, 80, "POST", $path, $query_string);
	
	return $id;
}

function feedsky_redr_doing() {
	global $feed, $withcomments;
	$feedsky_burn_url = get_option(FSP_FEEDURL);
	if ($feedsky_burn_url == "") {
		$feedsky_burn_url = "http://feed.feedsky.com/" . get_option(FSP_FEEDNAME);
	}
	if (is_feed() && ($feed != "comments-rss2") && ($withcomments != 1)) {
		if (function_exists('status_header')) status_header( 307 );
		header("Location:{$feedsky_burn_url}");
		header("HTTP/1.1 307 Temporary Redirect");
		exit();
	}
}

function feedsky_redr_init() {
	$feedsky_burn_url = get_option(FSP_FEEDURL);
	switch (basename($_SERVER['PHP_SELF'])) {
		case 'wp-rss.php':
		case 'wp-rss2.php':
		case 'wp-atom.php':
		case 'wp-rdf.php':
			if (function_exists('status_header')) status_header( 307 );
			header("Location:{$feedsky_burn_url}");
			header("HTTP/1.1 307 Temporary Redirect");
			exit();
			break;
	}
}

// FSP_PINGSERV
if ( get_option(FSP_PINGSERV) != 'off' ) add_action('publish_post', 'feedsky_ping_doing');
// FSP_REDRSERV
if ( get_option(FSP_REDRSERV) != 'off' ) {
	if (!preg_match("/feedsky/i", $_SERVER['HTTP_USER_AGENT'])) {
		add_action('template_redirect',  'feedsky_redr_doing');
		add_action('init', 'feedsky_redr_init');
	}
}

?>
