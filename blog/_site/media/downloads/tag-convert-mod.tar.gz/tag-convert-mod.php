<?php
/*
Plugin Name: Tag Converter 4 UTW - mod
Plugin URI: http://blog.istef.info/tag-converter
Description: Convert the Tags from UTW to WordPress (Mod with embedded tags import function)
Author: iStef (mod with wayne)
Version: 0.1 mod
Author URI: http://blog.istef.info/
*/ 

Class TM4UTW {
	var $tags = array();
	var $should_migr = false;
	var $embeded_tag_start = '[tag]';
	var $embeded_tag_end = '[/tag]';
	var $embeded_tags_start = '[tags]';
	var $embeded_tags_end = '[/tags]';
	var $mintagcolor = "#ffc4c4";
	var $maxtagcolor = "#ff0000";
	var $mintagfont = "70";
	var $maxtagfont = "250";
	var $fontweightunit = "%";
	
	function TM4UTW() {
		global $wpdb,$table_prefix;
		//initialize some tables
		$wpdb->tags = $table_prefix . "tags";
		$wpdb->post2tag = $table_prefix . "post2tag";
		$wpdb->tag_synonyms = $table_prefix . "tag_synonyms";
		if ($wpdb->get_var("SHOW TABLES LIKE '$wpdb->tags'") == $wpdb->tags) {
			// utw is still in the system
			if ($this->makeTagArray()) $this->should_migr = true;
		}
		add_action('admin_menu',array(&$this,'admin_menu'));
		if (get_option('tc_use_embeded_tags') == 'yes') {
			add_action('save_post', array(&$this,'saveEmbededTags'));
			add_filter('the_content',array(&$this,'ClearContentEmbededTags'));
		}
		if (!$this->should_migr) {
			if (!is_null(get_option('tc_tag_cloud_min_color'))) $this->mintagcolor = get_option('tc_tag_cloud_min_color');
			if (!is_null(get_option('tc_tag_cloud_max_color'))) $this->maxtagcolor = get_option('tc_tag_cloud_max_color');
			if (!is_null(get_option('tc_tag_cloud_min_font'))) $this->mintagfont = get_option('tc_tag_cloud_min_font');
			if (!is_null(get_option('tc_tag_cloud_max_font'))) $this->maxtagfont = get_option('tc_tag_cloud_max_font');
			if (!is_null(get_option('tc_tag_cloud_font_weight_unit'))) $this->fontweightunit = get_option('tc_tag_cloud_font_weight_unit');
		}
	}

	function getRelatePosts($tags,$limit = 0) {
		global $wpdb,$post;
		if (!is_array($tags) || (is_array($tags) && !count($tags))) return false;
		$now = current_time('mysql',1);
		$tag_list = implode(",",$tags);
		if ($limit > 0) $limitc = " LIMIT $limit";
		else $limitc = "";
		
		if ($post->ID) $exclude_post = " AND p.ID != $post->ID";
		else $exclude_post = "";
		
		$q = "SELECT p.*, COUNT(p2t.object_id) AS cnt
			  FROM $wpdb->posts AS p, $wpdb->term_taxonomy AS t, $wpdb->term_relationships AS p2t
			  WHERE p2t.term_taxonomy_id = t.term_taxonomy_id
			  AND t.taxonomy = 'post_tag'
			  AND p2t.object_id = p.ID
			  AND (t.term_id IN ($tag_list))
			  AND p.post_date_gmt < '$now'
			  AND p.post_type = 'post'
			  AND p.post_status = 'publish'
			  $exclude_post
			  GROUP BY p2t.object_id
			  ORDER BY cnt DESC, p.post_date_gmt DESC
			  $limitc";
		return $wpdb->get_results($q);
	}
	function getRelateTags($tags,$limit=0) {
		global $wpdb;
		if (!is_array($tags) || (is_array($tags) && !count($tags))) return false;
		$now = current_time('mysql',1);
		$tag_list = implode(",",$tags);
		if ($limit > 0) $limitc = " LIMIT $limit";
		else $limitc = "";
		$tagcount = count($tags);
		$q = "SELECT p2t.object_id
			  FROM $wpdb->posts AS p, $wpdb->term_taxonomy AS t, $wpdb->term_relationships AS p2t
			  WHERE p2t.term_taxonomy_id = t.term_taxonomy_id
			  AND t.taxonomy = 'post_tag'
			  AND p2t.object_id = p.ID
			  AND (t.term_id IN ($tag_list))
			  AND p.post_date_gmt < '$now'
			  AND p.post_type = 'post'
			  AND p.post_status = 'publish'
			  GROUP BY p2t.object_id HAVING COUNT(p2t.object_id)=$tagcount
			  ";
		$postids = (array) $wpdb->get_col($q);
		if (is_array($postids) && count($postids)) {
			$postidsc = implode(",",$postids);
			$q = "SELECT t.*, COUNT(p2t.object_id) AS cnt
				  FROM $wpdb->posts AS p, $wpdb->term_taxonomy AS t, $wpdb->term_relationships AS p2t
				  WHERE p2t.object_id IN ($postidsc)
				  AND p2t.object_id = p.ID
				  AND t.term_id NOT IN ($tag_list)
				  AND p2t.term_taxonomy_id = t.term_taxonomy_id
				  AND t.taxonomy = 'post_tag'
				  AND p.post_date_gmt < '$now'
				  AND p.post_type = 'post'
				  AND p.post_status = 'publish'
				  GROUP BY p2t.term_taxonomy_id
				  ORDER BY cnt DESC
				  $limitc";
			return $wpdb->get_results($q);
		}
	}
	function regExEscape($str) {
		$str = str_replace('\\', '\\\\', $str);
		$str = str_replace('/', '\\/', $str);
		$str = str_replace('[', '\\[', $str);
		$str = str_replace(']', '\\]', $str);
	
		return $str;
	}
	function ParseEmbededTags($post_content) {
		$tags = array();
		$regEx = "/" . $this->regExEscape($this->embeded_tag_start) . "\s*(.*?)\s*" . $this->regExEscape($this->embeded_tag_end) . "/i";
		preg_match_all($regEx,$post_content,$matches);
		foreach($matches[1] as $m) {
			$tags_arr = explode(",",$m);
			foreach ($tags_arr as $tag) array_push($tags,trim($tag));
		}
		$regEx2 = "/" . $this->regExEscape($this->embeded_tags_start) . "\s*(.*?)\s*" . $this->regExEscape($this->embeded_tags_end) . "/i";
		preg_match_all($regEx2,$post_content,$matches);
		foreach($matches[1] as $m) {
			$tags_arr = explode(",",$m);
			foreach ($tags_arr as $tag) array_push($tags,trim($tag));
		}
		return $tags;
	}
	function saveEmbededTags($postid) {
		$post = &get_post($postid);
		$tags = $this->ParseEmbededTags($post->post_content);
		if (!empty($tags)) {
			$tags = implode(', ',$tags);
			wp_set_post_tags($postid,$tags);
		}
	}
	function ClearContentEmbededTags($post_content) {
		$regEx = "/" . $this->regExEscape($this->embeded_tag_start) . "\s*(.*?)\s*" . $this->regExEscape($this->embeded_tag_end) . "/i";
		$regEx2 = "/" . $this->regExEscape($this->embeded_tags_start) . "\s*(.*?)\s*" . $this->regExEscape($this->embeded_tags_end) . "/i";
		$text = preg_replace($regEx,"",$post_content);
		$text = preg_replace($regEx2,"",$post_content);
		return $text;
	}
	
	function doMigr() {
		if (!$this->should_migr) return false;
		global $wpdb;
		//get all necessary posts first
		$post_ids = (array) $wpdb->get_col("SELECT DISTINCT post_id FROM $wpdb->post2tag");
		if (is_array($post_ids) && count($post_ids)) {
			foreach ($post_ids as $post_id) {
				//get tags of the post
				$tag_ids = (array) $wpdb->get_col("SELECT DISTINCT tag_id FROM $wpdb->post2tag WHERE post_id = $post_id");
				if (is_array($tag_ids) && count($tag_ids)) {
					$tag_str = "";
					foreach ($tag_ids as $tag_id) {
						if (!empty($this->tags[$tag_id])) {
							if (!empty($tag_str)) $tag_str .= ", ";
							$tag_str .= $this->tags[$tag_id];
						}
					}
					//use wp2.3 method to set the tags
					wp_set_post_tags($post_id,$tag_str);
				}
				//clear UTW cache of this post
				//no no, we clear them in one sql query later;
				//$this->ClearUTWCachePostMeta($post_id);
			}
			//clear all UTW Cache postmeta
			$wpdb->query("DELETE FROM $wpdb->postmeta WHERE meta_key LIKE '_utw_tags_%'");
			//remove utw tag tables
			$wpdb->query("DROP TABLE $wpdb->tags,$wpdb->post2tag,$wpdb->tag_synonyms");
			//remove some utw options, but we reserve some of them for further use
			update_option('tc_use_embedded_tags',get_option('utw_use_embedded_tags'));
			delete_option('utw_use_embedded_tags');
			update_option('tc_tag_cloud_max_color',get_option('utw_tag_cloud_max_color'));
			delete_option('utw_tag_cloud_max_color');
			update_option('tc_tag_cloud_min_color',get_option('utw_tag_cloud_min_color'));
			delete_option('utw_tag_cloud_min_color');
			update_option('tc_tag_cloud_max_font',get_option('utw_tag_cloud_max_font'));
			delete_option('utw_tag_cloud_max_font');
			update_option('tc_tag_cloud_min_font',get_option('utw_tag_cloud_min_font'));
			delete_option('utw_tag_cloud_min_font');
			update_option('tc_tag_cloud_font_weight_unit',get_option('utw_tag_cloud_font_units'));
			delete_option('utw_tag_cloud_font_units');

			$this->should_migr = false;
			
		} else {
			// it doesn't need to transform the tags because there is no tag at all.
			$this->should_migr = false;
		}
	}
	
	function ClearUTWCachePostMeta($postid) {
		if (!$this->should_migr) return false;
		global $wpdb;
		$postid = intval($postid);
		$wpdb->query("DELETE FROM $wpdb->postmeta WHERE meta_key LIKE '_utw_tags_%' AND post_id = '$postid'");
		return $postid;
	}
	function makeTagArray() {
		//put all tags in an array, so we can significantly reduce the number of DB queries.
		global $wpdb;
		$tags = $wpdb->get_results("SELECT * FROM $wpdb->tags");
		if ($tags && count($tags)) {
			$this->tags = array(); //clear the array;
			foreach ($tags as $tag) {
				//we should restore the tag first
				//all rules come from UTW
				$tag_display = str_replace('_',' ', $tag->tag);
				$tag_display = str_replace('-',' ',$tag_display);
				$tag_display = stripslashes($tag_display);
				//push tag into the array
				$this->tags[$tag->tag_ID] = $tag_display;
			}
			return true;
		} else return false;
	}
	//---------------------------------------------------------------------------------------------------------------------------------------------------------
	function admin_page() {
		if (!empty($_POST['utw_migr2wp'])) {
			$this->doMigr();
		?>
<div id="message" class="updated fade"><p><strong><?php _e('All tags has been converted.') ?></strong></p></div>
		<?php
		} elseif (!empty($_POST['tc_update_options'])) {
			update_option('tc_use_embeded_tags',$_POST['tc_use_embeded_tags']);
			update_option('tc_tag_cloud_max_color',$_POST['tc_tag_cloud_max_color']);
			update_option('tc_tag_cloud_min_color',$_POST['tc_tag_cloud_min_color']);
			update_option('tc_tag_cloud_max_font',$_POST['tc_tag_cloud_max_font']);
			update_option('tc_tag_cloud_min_font',$_POST['tc_tag_cloud_min_font']);
			update_option('tc_tag_cloud_font_weight_unit',$_POST['tc_tag_cloud_font_weight_unit']);
		?>
<div id="message" class="updated fade"><p><strong><?php _e('Settings Updated.') ?></strong></p></div>
<?php
		} elseif (!empty($_POST['import_embedded_tags'])) {
			import_embedded_tags ();
		}
		?>
<div class="wrap">
<h2><?php _e('Tag Converter for UTW'); ?></h2>
<p>
<?php if ($this->should_migr) { ?>
<form method="post">
	<?php _e("We found UTW tables in your system, you can just click the button below to convert them easily!") ?> <br />
	<input type="submit" name="utw_migr2wp" value="<?php _e("Start Convert!");?>" />
</form>
<?php } else { ?>
	<?php _e("No UTW Tags found in your system.");?>
	<form method="post">
	<fieldset><legend><?php _e("Use Embedded Tags");?>
		<p><strong><?php _e("Use UTW Style Embedded Tags: ");?></strong><input type="radio" name="tc_use_embeded_tags" value="yes"<?php echo (get_option('tc_use_embeded_tags')=='yes')?' checked':'';?> /><?php _e('Yes');?> <input type="radio" name="tc_use_embeded_tags" value="no"<?php echo (get_option('tc_use_embeded_tags')!='yes')?' checked':'';?> /><?php _e('No');?></p>
	</fieldset>
	<fieldset><legend><?php _e("Tag Cloud Settings");?>
		<p><strong><?php _e("Max Weight Color:");?></strong><input type="text" style="width: 200px;" name="tc_tag_cloud_max_color" value="<?php echo get_option('tc_tag_cloud_max_color');?>" /></p>
		<p><strong><?php _e("Min Weight Color:");?></strong><input type="text" style="width: 200px;" name="tc_tag_cloud_min_color" value="<?php echo get_option('tc_tag_cloud_min_color');?>" /></p>
		<p><strong><?php _e("Max Weight Size:");?></strong><input type="text" style="width: 200px;" name="tc_tag_cloud_max_font" value="<?php echo get_option('tc_tag_cloud_max_font');?>" /></p>
		<p><strong><?php _e("Min Weight Size:");?></strong><input type="text" style="width: 200px;" name="tc_tag_cloud_min_font" value="<?php echo get_option('tc_tag_cloud_min_font');?>" /></p>
		<p><strong><?php _e("Font Size Unit:");?></strong><input type="text" style="width: 200px;" name="tc_tag_cloud_font_weight_unit" value="<?php echo get_option('tc_tag_cloud_font_weight_unit');?>" /></p>
	</fieldset>
	
		<p class="submit">
			<input type="submit" name="tc_update_options" value="<?php _e("Update Options");?>" />
		</p>
	</form>
<?php } ?>
</p>
<h2>Import UTW embedded tags</h2>
<p>
<form method='post'>
<input type="submit" name="import_embedded_tags" value=<?php _e("Import Embedded Tags"); ?> />
</form>
</p>
</div>
<?php
	}
	function admin_menu() {
		add_options_page(__('Tag Converter'),__('Tag Converter'),'manage_options','tag-converter',array(&$this,'admin_page'));
	}
	//------------------------------------------------------------------------------------------------------------------
	/* This is pretty filthy.  Doing math in hex is much too weird.  It's more likely to work,  this way! */
	function GetColorForWeight($weight) {
		if ($weight) {
			$weight = $weight/100;

			$minr = hexdec(substr($this->mintagcolor, 1, 2));
			$ming = hexdec(substr($this->mintagcolor, 3, 2));
			$minb = hexdec(substr($this->mintagcolor, 5, 2));

			$maxr = hexdec(substr($this->maxtagcolor, 1, 2));
			$maxg = hexdec(substr($this->maxtagcolor, 3, 2));
			$maxb = hexdec(substr($this->maxtagcolor, 5, 2));

			$r = dechex(intval((($maxr - $minr) * $weight) + $minr));
			$g = dechex(intval((($maxg - $ming) * $weight) + $ming));
			$b = dechex(intval((($maxb - $minb) * $weight) + $minb));

			if (strlen($r) == 1) $r = "0" . $r;
			if (strlen($g) == 1) $g = "0" . $g;
			if (strlen($b) == 1) $b = "0" . $b;

			return "#$r$g$b";
		}
	}
	function GetFontSizeForWeight($weight) {

		if ($units == "") $units = '%';

		if ($this->maxtagfont > $this->mintagfont) {
			$fontsize = (($weight/100) * ($this->maxtagfont - $this->mintagfont)) + $this->mintagfont;
		} else {
			$fontsize = (((100-$weight)/100) * ($this->maxtagfont - $this->mintagfont)) + $this->maxtagfont;
		}

		return intval($fontsize) . $this->fontweightunit;
	}
	
}
$tm4utw = new TM4UTW;
function TC_ShowRelatedPostsForCurrentPost($limit=0,$before='<ul>',$after="</ul>",$showit = true) {
	global $tm4utw;
	$tags = get_the_tags();
	if (empty($tags)) return false;
	$tag_ids = array();
	foreach ($tags as $tag) {
		array_push($tag_ids,$tag->term_id);
	}
	$rps = $tm4utw->getRelatePosts($tag_ids,$limit);
	if (empty($rps)) return false;
	if (!$showit) return $rps;
	$out = '';
	foreach ($rps as $rp) {
		$out .= sprintf('<li><a href="%s">%s</a></li>',get_permalink($rp->ID),apply_filters('the_title', $rp->post_title, '', ''));
	}
	echo $before . $out . $after;
}

function import_embedded_tags() {
	global $tm4utw;
	global $wpdb;
	$posts = $wpdb->get_results ("SELECT ID, post_content FROM $wpdb->posts");
	foreach ($posts as $post) {
		$tags = $tm4utw->ParseEmbededTags ($post->post_content);
		if (!empty($tags)) {
			$tags = implode(', ',$tags);
			wp_set_post_tags($post->ID,$tags);
		}
										
	}
	?>
	<div id="message" class="updated fade"><p><strong><?php _e('Embedded tags imported.') ?></strong></p></div>
<?php
}
?>
