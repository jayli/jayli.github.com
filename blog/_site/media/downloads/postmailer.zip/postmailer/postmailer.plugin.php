<?php

class PostMailer extends Plugin
{
	public function info () {
		return array(
				'name' => 'Post Mailer',
				'version' => '0.2',
				'url' => 'http://gopherwood.info/2008/05/19/habari-plugin-post-mailer',
				'author' => 'Wayne Zhang',
				'authorurl' => 'http://gopherwood.info',
				'license' => 'Apache License 2.0',
				'description' => 'Send a post to email address.',
			    );
	}

	public function filter_plugin_config ($actions, $plugin_id) {
		if ($plugin_id == $this->plugin_id ()) {
			$actions[] =  _t('Configure');
		}
		
		return $actions;
	}
	
	public function action_plugin_ui ($plugin_id, $action) {
		if ($plugin_id == $this->plugin_id ()) {
			switch ($action) {
				case _t('Configure') :
					$form = new FormUI ('postmailer');
					$address = $form->append ('textmulti', 'address', 'option:postmailer__address',  _t('Email address: '));
					$subject = $form->append ('text', 'subject','option:postmailer__subject',  _t('Subject: '));
					$body = $form->append ('textarea', 'body', 'option:postmailer__body', _t('Body: '));
					$desc = $form->append ('static', 'desc', _t('Description: <br />You can use the escape string below in subject and body<br /><ul><li>%title% : as title of post</li><li>%author% : as author name of post</li><li>%link% : as permlink of post <strong>(can NOT in subject)</strong></li><li>%body% : as content of body <strong>(can NOT in subject)</strong></li></ul>'));
					$form->append( 'submit', 'save', 'Save' );
					$form->out ();
					break;
			}
		}
	}
	
	public function updated_config ($ui) {
		return true;
	}
	
	public function action_post_status_published ($post) {
		if ($post->status == Post::status ('published')) {
			$adds = Options::get ('postmailer__address');
			$subject = Options::get ('postmailer__subject'); 
			$body = Options::get ('postmailer__body'); 

			$author = $post->author->displayname; 
			$title = $post->title;
			$content = $post->content;
			$link = $post->permalink;

			// Replace escape string
			$sub = preg_replace ('/%title%/', $title, $subject);
			$sub = preg_replace ('/%author%/', $author, $sub);

			$message = preg_replace ('/%title%/', $title, $body);
			$message = preg_replace ('/%author%/', $author, $message);
			$message = preg_replace ('/%link%/', $link, $message);
			$message = preg_replace ('/%body%/', $content, $message);

			/* Base64 Encode content to avoid the unreadable content */
			$sub = "=?UTF-8?B?" . base64_encode ($sub) . "?=";
			$message = base64_encode ($message);

			foreach ($adds as $address) {
				EventLog::log ("Postmailer send to $address");
				mail ($address, $sub, $message, 
						"MIME-Version: 1.0" . PHP_EOL . "From: \"$author\" <$address>" . PHP_EOL . "X-Mailer: Habari" . PHP_EOL . "Content-Transfer-Encoding: base64" . PHP_EOL . "Content-Type: text/html; charset=utf-8" . PHP_EOL);
			}
		}
	}

	public function action_plugin_activation () {
		if (!Options::get('postmailer:installed')) {
			Options::set('postmailer:subject', '%title%');
			Options::set('postmailer:body', '%body%');
			Options::set('postmailer:installed', true);
		}
	}
}

?>
